Atelier lesson 3
Extract this entire archive. Open start/index.html in a browser. Edit files in start/ as the lesson directs. Compare with finish/index.html. Keep shared/ beside both folders. No installation or server is needed.

Study images: ELEVEN28 by Shayla, from the author's fashion landing-page project. Fonts: Clash Display and DM Sans, supplied with the course; see licensing details in shared/FONT-LICENSES.txt. The tone is an original generated test sound.
